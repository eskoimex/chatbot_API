import React, { Component } from 'react';
import * as compose from 'lodash.flowright';
import { graphql } from 'react-apollo';
//import {compose} from "recompose";
import { getFaqsQuery, addAnswerMutation} from '../queries/queries';

class AddAnswer extends Component {
    constructor(props){
        super(props);
        this.state = {
            answer: ''
        };
    }
    displayFaqs(){
        let data = this.props.getFaqsQuery;
        if(data.loading){
            return( <option disabled>Loading faqs</option> );
        } else {
            return data.faqs.map(faq => {
                return( <option key={ faq.id } value={faq.id}>{ faq.question }</option> );
            });
        }
    }
    submitForm(e){
        e.preventDefault()
        // use the addFaqMutation
        this.props.addAnswerMutation({
            variables: {
                answer: this.state.answer,
                faqId: this.state.faqId
            },
            refetchQueries: [{ query: getFaqsQuery }]
        });
    }
    render(){
        return(
            <form id="add-book" onSubmit={ this.submitForm.bind(this) } >
                <div className="field">
                    <label>Answer:</label>
                    <input type="text" onChange={ (e) => this.setState({ answer: e.target.value }) } />
                </div>
                <div className="field">
                    <label>Faq:</label>
                    <select onChange={ (e) => this.setState({ faqId: e.target.value }) } >
                        <option>Select faq</option>
                        { this.displayFaqs() }
                    </select>
                </div>
               
                <button>+</button>
            </form>
        );
    }
}

export default compose(
    graphql(getFaqsQuery, { name: "getFaqsQuery" }),
    graphql(addAnswerMutation, { name: "addAnswerMutation" })
)(AddAnswer);
