import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { getFaqQuery } from '../queries/queries';

class FaqDetails extends Component {
    displayFaqDetails(){
        const { faq } = this.props.data;
        if(faq){
            return(
                <div>
                    <h2>{ faq.question }</h2>
                    <p>All possible answers for this faq:</p>
                    <ul className="other-faqs">
                        { faq.answers.map(item => {
                            return <li key={item.id}>{ item.answer }</li>
                        })}
                    </ul>
                </div>
            );
        } else {
            return( <div>No faq selected...</div> );
        }
    }
    render(){
        return(
            <div id="faq-details">
                { this.displayFaqDetails() }
            </div>
        );
    }
}

export default graphql(getFaqQuery, {
    options: (props) => {
        return {
            variables: {
                id: props.faqId
            }
        }
    }
})(FaqDetails);
