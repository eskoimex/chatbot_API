import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { getFaqsQuery } from '../queries/queries';

// components
import FaqDetails from './FaqDetails';

class FaqList extends Component {
    constructor(props){
        super(props);
        this.state = {
            selected: null
        }
    }
    displayFaqs(){
        var data = this.props.data;
       console.log(data);

        if(data.loading){
            return( <div>Loading faqs...</div> );
        } else {
            return data.faqs.map(faq => {
                console.log(faq);

                return(
                    <li key={ faq.id } onClick={ (e) => this.setState({ selected: faq.id }) }>{ faq.question }</li>
                );
            })
        }
    }
    render(){
        return(
            <div>
                <ul id="faq-list">
                    { this.displayFaqs() }
                </ul>
                <FaqDetails faqId={ this.state.selected } />
            </div>
        );
    }
}

export default graphql(getFaqsQuery)(FaqList);
