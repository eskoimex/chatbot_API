import { gql } from 'apollo-boost';


const getIntroQuery = gql`
    {
        intro {
            message1
            message2
        }
    }
`;

const getFaqsQuery = gql`
    {
        faqs {
            question
            id
        }
    }
`;

const getFaqQuery = gql`
    query GetFaq($id: ID){
        faq(id: $id) {
            id
            question
            answers {
                id
                answer
                faqId
            }
        }
    }
`;


const getAnswersQuery = gql`
    {
        answer {
            answer
            id
            faqId
        }
    }
`;

const addFaqMutation = gql`
    mutation AddFaq($question: String!){
        addFaq(question: $question){
            question
            id
        }
    }
`;

const addAnswerMutation = gql`
    mutation AddAnswer($answer: String!, $faqId: ID!){
        addAnswer(answer: $answer, faqId: $faqId){
            answer
            id
        }
    }
`;



const getAnswerQuery = gql`
    query GetAnswer($id: ID){
        answer(id: $id) {
            id
            answer
            faqId
        }
    }
`;




export { getFaqsQuery, getIntroQuery, getAnswerQuery, getAnswersQuery, addFaqMutation, addAnswerMutation, getFaqQuery };
