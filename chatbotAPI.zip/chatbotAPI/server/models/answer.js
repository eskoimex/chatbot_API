const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const answerSchema = new Schema({
    answer: String,
    faqId: String
});

module.exports = mongoose.model('Answer', answerSchema);
