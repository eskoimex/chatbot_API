const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const introSchema = new Schema({
    message1: String,
    message2: String
});

module.exports = mongoose.model('Intro', introSchema);
