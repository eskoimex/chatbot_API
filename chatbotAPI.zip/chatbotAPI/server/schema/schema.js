const graphql = require('graphql');
const Faq = require('../models/faq');
const Answer = require('../models/answer');
const Intro = require('../models/intro');
const _ = require('lodash');

// DECLARE DIFFERENT GRAPHQL OBJECT TYPES
const {
    GraphQLObjectType,
    GraphQLString,
    GraphQLSchema,
    GraphQLID,
    GraphQLInt,
    GraphQLList,
    GraphQLNonNull
} = graphql;


//----------DEFINE OBJECT TYPES FOR DATABASE FIELDS--------------------//

// INTRO OBJECT TYPES
const IntroType = new GraphQLObjectType({
    name: 'Intro',
    fields: ( ) => ({
        id: { type: GraphQLID },
        message1: { type: GraphQLString },
        message2: { type: GraphQLString }

    })
});

// FAQ OBJECT TYPES
const FaqType = new GraphQLObjectType({
    name: 'Faq',
    fields: ( ) => ({
        id: { type: GraphQLID },
        question: { type: GraphQLString },
        answers: {
            type: new GraphQLList(AnswerType),
            resolve(parent, args){
                return Answer.find({ faqId: parent.id });
            }
        }
    })
});

// ANSWER OBJECT TYPES
const AnswerType = new GraphQLObjectType({
    name: 'Answer',
    fields: ( ) => ({
        id: { type: GraphQLID },
        answer: { type: GraphQLString },
        faqId: { type: GraphQLString }
    })
})


//--------- DEFINES SEVERAL QUERYS -------//

const RootQuery = new GraphQLObjectType({
    name: 'RootQueryType',
    fields: {
        //SELECT * FROM intro WHERE id = {id}
        intro: {
            type: IntroType,
            args: { id: { type: GraphQLID } },
            resolve(parent, args){
                return Intro.findById(args.id);
            }
        },    
        // SELECT * FROM faq WHERE id = {id}
        faq: {
            type: FaqType,
            args: { id: { type: GraphQLID } },
            resolve(parent, args){
                return Faq.findById(args.id);
            }
        },
        // SELECT * FROM answers WHERE id = {id}
        answer: {
            type: AnswerType,
            args: { id: { type: GraphQLID } },
            resolve(parent, args){
                return Answer.findById(args.id);
            }
        },
        // SELECT ALL 
         // SELECT * FROM intro
         intros: {
            type: new GraphQLList(IntroType),
            resolve(parent, args){
               // return faqs;
               return Intro.find({});
            }
        },
        // SELECT * FROM faqs
        faqs: {
            type: new GraphQLList(FaqType),
            resolve(parent, args){
               // return faqs;
               return Faq.find({});
            }
        },
        // SELECT * FROM answers
        answers: {
            type: new GraphQLList(AnswerType),
            resolve(parent, args){
                return Answer.find({});
            }
        }
    }
});

//PERFORM INSERT USING MUTATION
const Mutation = new GraphQLObjectType({
    name: 'Mutation',
    fields: {
        // INSERT message1, message2 INTO intro
        addIntro: {
            type: IntroType,
            args: {
                message1: { type: GraphQLString },
                message2: { type: GraphQLString },
            },
            resolve(parent, args){
                let intro = new Intro({
                    message1: args.message1,
                    message2: args.message2
                });

                return intro.save();
            }
        },
       // INSERT question INTO faq
        addFaq: {
            type: FaqType,
            args: {
                question: { type: GraphQLString },
            },
            resolve(parent, args){
                let faq = new Faq({
                    question: args.question
                });
                return faq.save();
            }
        },
          // INSERT answer INTO answers
          addAnswer: {
            type: AnswerType,
            args: {
                answer: { type: new GraphQLNonNull(GraphQLString) },
                faqId: { type: GraphQLID }
            },
            resolve(parent, args){
                let answer = new Answer({
                    answer: args.answer,
                    faqId: args.faqId
                });
                return answer.save();
            }
        }
    }
});

module.exports = new GraphQLSchema({
    query: RootQuery,
    mutation: Mutation
});
